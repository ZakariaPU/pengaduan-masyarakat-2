<h1>Status Pengaduan</h1>
<p>Status Anda saat ini: {{ $status }}</p>
