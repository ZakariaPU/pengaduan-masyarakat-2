<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitor Counter</title>
</head>
<body>
    <h1>Welcome to our website!</h1>
    <p>Total Visits (Reload Count): {{ $visitorCount }}</p>
</body>
</html>
